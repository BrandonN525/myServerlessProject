# myServerlessProject
Serverless AWS Project using Lambda, S3, DynamoDB, and API Gateway
